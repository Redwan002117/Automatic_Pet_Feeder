/**
 * Main JavaScript file for Automatic Pet Feeder Web Application
 * Contains shared functionality used across multiple pages
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize mobile menu toggle
    initMobileMenu();
    
    // Initialize dropdowns
    initDropdowns();
    
    // Initialize tooltips
    initTooltips();
    
    // Initialize modals
    initModals();
    
    // Handle loading states for forms
    initFormLoadingStates();
});

/**
 * Initialize mobile menu functionality
 */
function initMobileMenu() {
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const siteHeader = document.querySelector('.site-header');
    
    if (mobileMenuToggle && siteHeader) {
        mobileMenuToggle.addEventListener('click', () => {
            siteHeader.classList.toggle('mobile-menu-open');
            
            // Toggle aria-expanded attribute for accessibility
            const isExpanded = siteHeader.classList.contains('mobile-menu-open');
            mobileMenuToggle.setAttribute('aria-expanded', isExpanded);
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', (event) => {
            if (siteHeader.classList.contains('mobile-menu-open') && 
                !event.target.closest('.main-nav') && 
                !event.target.closest('.mobile-menu-toggle')) {
                siteHeader.classList.remove('mobile-menu-open');
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }
    
    // For dashboard sidebar toggle
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const dashboardContainer = document.querySelector('.dashboard-container');
    
    if (sidebarToggle && dashboardContainer) {
        sidebarToggle.addEventListener('click', () => {
            dashboardContainer.classList.toggle('sidebar-collapsed');
            
            // Toggle aria-expanded attribute for accessibility
            const isExpanded = !dashboardContainer.classList.contains('sidebar-collapsed');
            sidebarToggle.setAttribute('aria-expanded', isExpanded);
        });
    }
}

/**
 * Initialize dropdown functionality
 */
function initDropdowns() {
    const dropdownTriggers = document.querySelectorAll('[data-dropdown]');
    
    dropdownTriggers.forEach(trigger => {
        // Store the related dropdown
        const dropdown = trigger.nextElementSibling || document.querySelector(trigger.getAttribute('data-dropdown'));
        
        if (dropdown) {
            trigger.addEventListener('click', (event) => {
                event.stopPropagation();
                
                // Close all other dropdowns first
                document.querySelectorAll('.dropdown-visible').forEach(openDropdown => {
                    if (openDropdown !== dropdown) {
                        openDropdown.classList.remove('dropdown-visible');
                        
                        // Update related trigger's aria-expanded attribute
                        const relatedTrigger = document.querySelector(`[data-dropdown="#${openDropdown.id}"]`) || openDropdown.previousElementSibling;
                        if (relatedTrigger) {
                            relatedTrigger.setAttribute('aria-expanded', 'false');
                        }
                    }
                });
                
                // Toggle current dropdown
                dropdown.classList.toggle('dropdown-visible');
                
                // Update aria-expanded attribute
                const isExpanded = dropdown.classList.contains('dropdown-visible');
                trigger.setAttribute('aria-expanded', isExpanded);
            });
        }
    });
    
    // Click outside to close dropdowns
    document.addEventListener('click', (event) => {
        if (!event.target.closest('[data-dropdown]') && !event.target.closest('.dropdown-visible')) {
            document.querySelectorAll('.dropdown-visible').forEach(dropdown => {
                dropdown.classList.remove('dropdown-visible');
                
                // Update related trigger's aria-expanded attribute
                const trigger = document.querySelector(`[data-dropdown="#${dropdown.id}"]`) || dropdown.previousElementSibling;
                if (trigger) {
                    trigger.setAttribute('aria-expanded', 'false');
                }
            });
        }
    });
    
    // Specific elements with dropdown behavior
    const notificationBell = document.querySelector('.notification-bell');
    const notificationDropdown = document.querySelector('.notification-dropdown');
    const profileButton = document.querySelector('.profile-button');
    const profileDropdown = document.querySelector('.profile-dropdown');
    
    if (notificationBell && notificationDropdown) {
        notificationBell.addEventListener('click', (event) => {
            event.stopPropagation();
            notificationDropdown.classList.toggle('visible');
            profileDropdown?.classList.remove('visible');
        });
    }
    
    if (profileButton && profileDropdown) {
        profileButton.addEventListener('click', (event) => {
            event.stopPropagation();
            profileDropdown.classList.toggle('visible');
            notificationDropdown?.classList.remove('visible');
        });
    }
}

/**
 * Initialize tooltips functionality
 */
function initTooltips() {
    const tooltipTriggers = document.querySelectorAll('[title]:not([data-no-tooltip])');
    
    tooltipTriggers.forEach(trigger => {
        const tooltipText = trigger.getAttribute('title');
        
        // Create tooltip element
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = tooltipText;
        
        // Remove the title attribute to prevent default browser tooltip
        trigger.removeAttribute('title');
        trigger.setAttribute('data-tooltip', tooltipText);
        
        // Add tooltip to the body
        document.body.appendChild(tooltip);
        
        // Show tooltip on hover/focus
        const showTooltip = () => {
            const triggerRect = trigger.getBoundingClientRect();
            
            tooltip.classList.add('visible');
            
            // Position the tooltip above the element
            const tooltipRect = tooltip.getBoundingClientRect();
            tooltip.style.left = `${triggerRect.left + (triggerRect.width / 2) - (tooltipRect.width / 2)}px`;
            tooltip.style.top = `${triggerRect.top - tooltipRect.height - 10}px`;
        };
        
        // Hide tooltip
        const hideTooltip = () => {
            tooltip.classList.remove('visible');
        };
        
        // Add event listeners
        trigger.addEventListener('mouseenter', showTooltip);
        trigger.addEventListener('mouseleave', hideTooltip);
        trigger.addEventListener('focus', showTooltip);
        trigger.addEventListener('blur', hideTooltip);
    });
}

/**
 * Initialize modal functionality
 */
function initModals() {
    // Modal triggers
    const modalTriggers = document.querySelectorAll('[data-modal]');
    const modalCloseButtons = document.querySelectorAll('.modal-close, [data-modal-close]');
    
    // Open modal when trigger is clicked
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', (event) => {
            event.preventDefault();
            
            const modalId = trigger.getAttribute('data-modal');
            const modal = document.getElementById(modalId);
            
            if (modal) {
                openModal(modal);
            }
        });
    });
    
    // Close modal when close button is clicked
    modalCloseButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal');
            if (modal) {
                closeModal(modal);
            }
        });
    });
    
    // Close modal when clicking outside content
    document.addEventListener('click', (event) => {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target);
        }
    });
    
    // Close modal with Escape key
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            const openModal = document.querySelector('.modal.visible');
            if (openModal) {
                closeModal(openModal);
            }
        }
    });
    
    // Handle the feed-now button in the dashboard
    const feedNowButtons = document.querySelectorAll('[data-device-id]');
    const feedNowModal = document.getElementById('feed-now-modal');
    
    if (feedNowButtons.length > 0 && feedNowModal) {
        feedNowButtons.forEach(button => {
            if (button.textContent.includes('Feed Now')) {
                button.addEventListener('click', () => {
                    const deviceId = button.getAttribute('data-device-id');
                    // Optional: Store the device ID in the modal form for submission
                    const deviceInput = document.createElement('input');
                    deviceInput.type = 'hidden';
                    deviceInput.name = 'device-id';
                    deviceInput.value = deviceId;
                    
                    const form = feedNowModal.querySelector('form');
                    // Remove any existing device ID input
                    const existingDeviceInput = form.querySelector('input[name="device-id"]');
                    if (existingDeviceInput) {
                        existingDeviceInput.remove();
                    }
                    
                    form.appendChild(deviceInput);
                    
                    openModal(feedNowModal);
                });
            }
        });
        
        // Cancel button in the feed now modal
        const cancelFeedButton = document.getElementById('cancel-feed');
        if (cancelFeedButton) {
            cancelFeedButton.addEventListener('click', () => {
                closeModal(feedNowModal);
            });
        }
        
        // Handle portion size selection in feed now modal
        const feedPortionSelect = document.getElementById('feed-portion');
        const customPortionDiv = document.querySelector('.custom-portion');
        
        if (feedPortionSelect && customPortionDiv) {
            feedPortionSelect.addEventListener('change', () => {
                if (feedPortionSelect.value === 'custom') {
                    customPortionDiv.style.display = 'block';
                } else {
                    customPortionDiv.style.display = 'none';
                }
            });
        }
    }
}

/**
 * Open a modal
 */
function openModal(modal) {
    // Make modal visible
    modal.classList.add('visible');
    
    // Set focus on the first focusable element
    const focusableElements = modal.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
    if (focusableElements.length > 0) {
        focusableElements[0].focus();
    }
    
    // Prevent scrolling of the body
    document.body.classList.add('modal-open');
}

/**
 * Close a modal
 */
function closeModal(modal) {
    // Hide modal
    modal.classList.remove('visible');
    
    // Re-enable scrolling of the body
    document.body.classList.remove('modal-open');
    
    // Clear any form inside the modal
    const form = modal.querySelector('form');
    if (form) {
        form.reset();
    }
    
    // Return focus to the element that opened the modal
    const modalId = modal.id;
    const trigger = document.querySelector(`[data-modal="${modalId}"]`);
    if (trigger) {
        trigger.focus();
    }
}

/**
 * Initialize form loading states
 */
function initFormLoadingStates() {
    const forms = document.querySelectorAll('form:not([data-no-loading])');
    
    forms.forEach(form => {
        form.addEventListener('submit', () => {
            const submitButton = form.querySelector('button[type="submit"]');
            
            if (submitButton && !submitButton.disabled) {
                const originalText = submitButton.textContent;
                const loadingText = submitButton.getAttribute('data-loading-text') || 'Processing...';
                
                // Store original text for restoration later
                submitButton.setAttribute('data-original-text', originalText);
                
                // Update button and disable
                submitButton.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${loadingText}`;
                submitButton.disabled = true;
                
                // Restore button state if submission takes too long (failsafe)
                // This is a backup in case the form submission logic doesn't handle errors properly
                setTimeout(() => {
                    if (submitButton.disabled) {
                        submitButton.innerHTML = originalText;
                        submitButton.disabled = false;
                    }
                }, 10000); // 10 seconds timeout
            }
        });
    });
}

/**
 * Format date and time
 * @param {Date|string} dateTime Date object or date string
 * @param {string} format Format options: 'datetime', 'date', 'time', 'relative'
 */
function formatDateTime(dateTime, format = 'datetime') {
    const date = typeof dateTime === 'string' ? new Date(dateTime) : dateTime;
    
    // Check if date is valid
    if (isNaN(date.getTime())) {
        return 'Invalid date';
    }
    
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    // Format as relative time
    if (format === 'relative') {
        if (diffMins < 1) {
            return 'Just now';
        } else if (diffMins < 60) {
            return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
        } else if (diffHours < 24) {
            return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
        } else if (diffDays < 7) {
            return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
        }
    }
    
    // Format options
    const options = {
        dateStyle: format === 'time' ? undefined : 'medium',
        timeStyle: format === 'date' ? undefined : 'short'
    };
    
    return date.toLocaleString(undefined, options);
}

/**
 * Format number with commas for thousands
 */
function formatNumber(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Truncate text with ellipsis
 */
function truncateText(text, maxLength) {
    if (text.length <= maxLength) {
        return text;
    }
    
    return text.substring(0, maxLength) + '...';
} 