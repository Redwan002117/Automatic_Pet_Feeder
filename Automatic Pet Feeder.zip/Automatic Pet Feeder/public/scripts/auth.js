/**
 * Authentication functionality for Automatic Pet Feeder
 * Handles login, signup, password reset, and social logins
 */

// Initialize Supabase client
let supabase;

document.addEventListener('DOMContentLoaded', async function() {
    // Initialize Supabase client
    supabase = await initSupabase();

    // Check if we're on a protected page and redirect if not authenticated
    const isProtectedPage = !['index.html', 'login.html', 'signup.html', 'reset-password.html'].some(page => 
        window.location.pathname.endsWith(page)
    );

    if (isProtectedPage) {
        const user = await checkAuth();
        if (!user) {
            window.location.href = 'login.html?redirect=' + encodeURIComponent(window.location.pathname);
            return;
        }
    }

    // Add event listeners for forms
    setupAuthForms();
    
    // Handle authentication UI state
    updateAuthUI();
    
    // Toggle between auth forms (login/magic link)
    setupAuthTabs();
    
    // Setup password visibility toggle
    setupPasswordToggle();
    
    // Setup password strength meter if we're on signup page
    if (document.getElementById('password-strength-meter')) {
        setupPasswordStrengthMeter();
    }
});

/**
 * Initialize Supabase client
 */
async function initSupabase() {
    try {
        // In a production environment, these would be loaded from environment variables
        const SUPABASE_URL = 'https://your-supabase-url.supabase.co';
        const SUPABASE_ANON_KEY = 'your-supabase-anon-key';
        
        return supabaseClient.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    } catch (error) {
        console.error('Error initializing Supabase client:', error);
        showError('Could not initialize application. Please try again later.');
        return null;
    }
}

/**
 * Check if user is authenticated
 */
async function checkAuth() {
    try {
        const { data: { user }, error } = await supabase.auth.getUser();
        
        if (error) {
            throw error;
        }
        
        return user;
    } catch (error) {
        console.error('Error checking authentication:', error);
        return null;
    }
}

/**
 * Set up event listeners for auth forms
 */
function setupAuthForms() {
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Magic link form
    const magicLinkForm = document.getElementById('magic-link-form');
    if (magicLinkForm) {
        magicLinkForm.addEventListener('submit', handleMagicLink);
    }
    
    // Signup form
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup);
    }
    
    // Social login buttons
    const googleLoginBtn = document.getElementById('google-login') || document.getElementById('google-signup');
    if (googleLoginBtn) {
        googleLoginBtn.addEventListener('click', () => handleSocialLogin('google'));
    }
    
    const facebookLoginBtn = document.getElementById('facebook-login') || document.getElementById('facebook-signup');
    if (facebookLoginBtn) {
        facebookLoginBtn.addEventListener('click', () => handleSocialLogin('facebook'));
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logout-button');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    const dropdownLogoutBtn = document.getElementById('dropdown-logout');
    if (dropdownLogoutBtn) {
        dropdownLogoutBtn.addEventListener('click', handleLogout);
    }
}

/**
 * Handle login form submission
 */
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('remember')?.checked || false;
    
    // Basic validation
    if (!email || !password) {
        showError('Please enter your email and password', 'login-error');
        return;
    }
    
    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
    
    try {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
            options: {
                // Set session duration to 30 days if remember me is checked
                expiresIn: rememberMe ? 30 * 24 * 60 * 60 : 60 * 60
            }
        });
        
        if (error) {
            throw error;
        }
        
        // Get the redirect URL from query parameters
        const params = new URLSearchParams(window.location.search);
        const redirectUrl = params.get('redirect') || 'dashboard.html';
        
        // Redirect to dashboard or another protected page
        window.location.href = redirectUrl;
    } catch (error) {
        console.error('Login error:', error);
        
        let errorMessage = 'Failed to login. Please check your credentials.';
        if (error.message) {
            errorMessage = error.message;
        }
        
        showError(errorMessage, 'login-error');
        
        // Reset button state
        submitBtn.disabled = false;
        submitBtn.textContent = originalBtnText;
    }
}

/**
 * Handle magic link form submission
 */
async function handleMagicLink(event) {
    event.preventDefault();
    
    const email = document.getElementById('magic-email').value;
    
    // Basic validation
    if (!email) {
        showError('Please enter your email', 'magic-link-error');
        return;
    }
    
    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    
    try {
        const { data, error } = await supabase.auth.signInWithOtp({
            email,
            options: {
                emailRedirectTo: window.location.origin + '/dashboard.html'
            }
        });
        
        if (error) {
            throw error;
        }
        
        // Show success message
        const successEl = document.getElementById('magic-link-success');
        successEl.textContent = `Magic link has been sent to ${email}. Please check your inbox.`;
        successEl.style.display = 'block';
        
        // Clear the error message if present
        document.getElementById('magic-link-error').style.display = 'none';
        
        // Reset the form
        event.target.reset();
    } catch (error) {
        console.error('Magic link error:', error);
        
        let errorMessage = 'Failed to send magic link. Please try again.';
        if (error.message) {
            errorMessage = error.message;
        }
        
        showError(errorMessage, 'magic-link-error');
        
        // Hide any previous success message
        document.getElementById('magic-link-success').style.display = 'none';
    } finally {
        // Reset button state
        submitBtn.disabled = false;
        submitBtn.textContent = originalBtnText;
    }
}

/**
 * Handle signup form submission
 */
async function handleSignup(event) {
    event.preventDefault();
    
    const fullName = document.getElementById('full-name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const termsAccepted = document.getElementById('terms').checked;
    
    // Basic validation
    if (!fullName || !email || !password) {
        showError('Please fill out all required fields', 'signup-error');
        return;
    }
    
    if (password.length < 8) {
        showError('Password must be at least 8 characters long', 'signup-error');
        return;
    }
    
    if (password !== confirmPassword) {
        showError('Passwords do not match', 'signup-error');
        return;
    }
    
    if (!termsAccepted) {
        showError('You must accept the Terms of Service and Privacy Policy', 'signup-error');
        return;
    }
    
    // Password strength check
    const passwordStrength = checkPasswordStrength(password);
    if (passwordStrength < 3) {
        showError('Please use a stronger password', 'signup-error');
        return;
    }
    
    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating account...';
    
    try {
        // Register user
        const { data: { user }, error: signUpError } = await supabase.auth.signUp({
            email,
            password,
            options: {
                data: {
                    display_name: fullName
                },
                emailRedirectTo: window.location.origin + '/dashboard.html'
            }
        });
        
        if (signUpError) {
            throw signUpError;
        }
        
        // Redirect to confirmation page or dashboard depending on email confirmation settings
        window.location.href = 'signup-success.html';
    } catch (error) {
        console.error('Signup error:', error);
        
        let errorMessage = 'Failed to create account. Please try again.';
        if (error.message) {
            errorMessage = error.message;
        }
        
        showError(errorMessage, 'signup-error');
        
        // Reset button state
        submitBtn.disabled = false;
        submitBtn.textContent = originalBtnText;
    }
}

/**
 * Handle social login (Google, Facebook)
 */
async function handleSocialLogin(provider) {
    try {
        const { data, error } = await supabase.auth.signInWithOAuth({
            provider,
            options: {
                redirectTo: window.location.origin + '/dashboard.html'
            }
        });
        
        if (error) {
            throw error;
        }
        
        // The user will be redirected to the OAuth provider
    } catch (error) {
        console.error(`${provider} login error:`, error);
        
        let errorId = 'login-error';
        if (window.location.pathname.includes('signup')) {
            errorId = 'signup-error';
        }
        
        showError(`Failed to login with ${provider}. Please try again.`, errorId);
    }
}

/**
 * Handle logout
 */
async function handleLogout(event) {
    event.preventDefault();
    
    try {
        const { error } = await supabase.auth.signOut();
        
        if (error) {
            throw error;
        }
        
        // Redirect to login page
        window.location.href = 'login.html';
    } catch (error) {
        console.error('Logout error:', error);
        alert('Failed to logout. Please try again.');
    }
}

/**
 * Toggle between auth forms (login/magic link)
 */
function setupAuthTabs() {
    const authOptions = document.querySelectorAll('.auth-option');
    
    if (authOptions.length > 0) {
        authOptions.forEach(option => {
            option.addEventListener('click', function() {
                // Remove active class from all options
                authOptions.forEach(opt => opt.classList.remove('active'));
                
                // Add active class to clicked option
                this.classList.add('active');
                
                // Hide all forms
                document.querySelectorAll('.auth-form').forEach(form => {
                    form.classList.remove('active');
                });
                
                // Show the selected form
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
                
                // Clear error messages
                document.querySelectorAll('.auth-error, .auth-success').forEach(el => {
                    el.style.display = 'none';
                });
            });
        });
    }
}

/**
 * Setup password visibility toggle
 */
function setupPasswordToggle() {
    const toggleBtns = document.querySelectorAll('.password-toggle');
    
    if (toggleBtns.length > 0) {
        toggleBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.parentElement.querySelector('input');
                const icon = this.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
    }
}

/**
 * Setup password strength meter
 */
function setupPasswordStrengthMeter() {
    const passwordInput = document.getElementById('password');
    const strengthBar = document.querySelector('.strength-bar');
    const passwordRequirements = document.querySelectorAll('[data-requirement]');
    
    if (passwordInput && strengthBar) {
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = checkPasswordStrength(password);
            
            // Update strength bar
            strengthBar.style.width = `${strength * 25}%`;
            
            // Update color based on strength
            if (strength === 0) {
                strengthBar.style.backgroundColor = '#ddd';
            } else if (strength === 1) {
                strengthBar.style.backgroundColor = '#ff4d4d';
            } else if (strength === 2) {
                strengthBar.style.backgroundColor = '#ffa500';
            } else if (strength === 3) {
                strengthBar.style.backgroundColor = '#2ecc71';
            } else {
                strengthBar.style.backgroundColor = '#27ae60';
            }
            
            // Update password requirements
            updatePasswordRequirements(password);
        });
    }
}

/**
 * Check password strength
 * Returns a score from 0 to 4
 */
function checkPasswordStrength(password) {
    // Empty password
    if (!password) {
        return 0;
    }
    
    let score = 0;
    
    // Length check
    if (password.length >= 8) {
        score += 1;
    }
    
    // Complexity checks
    if (/[A-Z]/.test(password)) {
        score += 1;
    }
    
    if (/[0-9]/.test(password)) {
        score += 1;
    }
    
    if (/[^A-Za-z0-9]/.test(password)) {
        score += 1;
    }
    
    return Math.min(score, 4);
}

/**
 * Update password requirements UI
 */
function updatePasswordRequirements(password) {
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[^A-Za-z0-9]/.test(password)
    };
    
    Object.entries(requirements).forEach(([requirement, isMet]) => {
        const reqEl = document.querySelector(`[data-requirement="${requirement}"]`);
        
        if (reqEl) {
            const icon = reqEl.querySelector('i');
            
            if (isMet) {
                icon.classList.remove('fa-times-circle');
                icon.classList.add('fa-check-circle');
                reqEl.classList.add('met');
            } else {
                icon.classList.remove('fa-check-circle');
                icon.classList.add('fa-times-circle');
                reqEl.classList.remove('met');
            }
        }
    });
}

/**
 * Update UI based on authentication state
 */
async function updateAuthUI() {
    try {
        const { data: { user }, error } = await supabase.auth.getUser();
        
        if (error) {
            throw error;
        }
        
        // If we have a user
        if (user) {
            // Hide login/register buttons if on homepage
            const authButtons = document.querySelector('.auth-buttons');
            if (authButtons) {
                authButtons.innerHTML = `
                    <a href="dashboard.html" class="btn btn-primary">Dashboard</a>
                    <button id="header-logout-btn" class="btn btn-outline">Logout</button>
                `;
                
                // Add event listener to the logout button
                document.getElementById('header-logout-btn').addEventListener('click', handleLogout);
            }
            
            // Update profile info if on dashboard
            const profileName = document.getElementById('profile-name');
            if (profileName) {
                profileName.textContent = user.user_metadata?.display_name || user.email.split('@')[0];
            }
            
            // Update profile image if on dashboard
            const profileImage = document.getElementById('profile-image');
            if (profileImage) {
                if (user.user_metadata?.avatar_url) {
                    profileImage.src = user.user_metadata.avatar_url;
                }
            }
        } else {
            // If on a protected page, redirect to login
            const isProtectedPage = !['index.html', 'login.html', 'signup.html', 'reset-password.html'].some(page => 
                window.location.pathname.endsWith(page)
            );
            
            if (isProtectedPage) {
                window.location.href = 'login.html?redirect=' + encodeURIComponent(window.location.pathname);
            }
        }
    } catch (error) {
        console.error('Error updating auth UI:', error);
    }
}

/**
 * Show error message
 */
function showError(message, elementId = 'login-error') {
    const errorEl = document.getElementById(elementId);
    if (errorEl) {
        errorEl.textContent = message;
        errorEl.style.display = 'block';
    } else {
        console.error(message);
    }
} 