/**
 * Landing page JavaScript for Automatic Pet Feeder
 * Handles landing page specific functionality like testimonial slider, 
 * smooth scrolling, and contact form.
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize testimonial slider
    initTestimonialSlider();
    
    // Initialize smooth scrolling for anchor links
    initSmoothScroll();
    
    // Initialize contact form
    initContactForm();
    
    // Check authentication status to update header buttons
    checkAuthStatus();
});

/**
 * Initialize testimonial slider
 */
function initTestimonialSlider() {
    const testimonialSlides = document.querySelectorAll('.testimonial-slide');
    const indicators = document.querySelectorAll('.testimonial-indicators .indicator');
    const prevBtn = document.querySelector('.prev-testimonial');
    const nextBtn = document.querySelector('.next-testimonial');
    
    if (!testimonialSlides.length) return;
    
    let currentSlide = 0;
    let slideInterval;
    
    // Function to show a specific slide
    function showSlide(index) {
        // Remove active class from all slides
        testimonialSlides.forEach(slide => {
            slide.classList.remove('active');
        });
        
        // Remove active class from all indicators
        indicators.forEach(indicator => {
            indicator.classList.remove('active');
        });
        
        // Add active class to current slide and indicator
        testimonialSlides[index].classList.add('active');
        if (indicators[index]) {
            indicators[index].classList.add('active');
        }
        
        currentSlide = index;
    }
    
    // Function to show next slide
    function nextSlide() {
        const newIndex = (currentSlide + 1) % testimonialSlides.length;
        showSlide(newIndex);
    }
    
    // Function to show previous slide
    function prevSlide() {
        const newIndex = (currentSlide - 1 + testimonialSlides.length) % testimonialSlides.length;
        showSlide(newIndex);
    }
    
    // Add click event listeners to indicators
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            showSlide(index);
            resetInterval();
        });
    });
    
    // Add click event listeners to navigation buttons
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            prevSlide();
            resetInterval();
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            nextSlide();
            resetInterval();
        });
    }
    
    // Auto-advance slides
    function startInterval() {
        slideInterval = setInterval(nextSlide, 5000);
    }
    
    function resetInterval() {
        clearInterval(slideInterval);
        startInterval();
    }
    
    // Start auto-advancing
    startInterval();
    
    // Pause auto-advance on hover
    const sliderContainer = document.querySelector('.testimonial-slider');
    if (sliderContainer) {
        sliderContainer.addEventListener('mouseenter', () => {
            clearInterval(slideInterval);
        });
        
        sliderContainer.addEventListener('mouseleave', () => {
            startInterval();
        });
    }
}

/**
 * Initialize smooth scrolling for anchor links
 */
function initSmoothScroll() {
    const anchorLinks = document.querySelectorAll('a[href^="#"]:not([href="#"])');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                // Get header height to adjust scroll position
                const header = document.querySelector('.site-header');
                const headerHeight = header ? header.offsetHeight : 0;
                
                // Calculate position to scroll to
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                // Scroll smoothly to target
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Update URL hash without scrolling
                history.pushState(null, null, targetId);
            }
        });
    });
}

/**
 * Initialize contact form
 */
function initContactForm() {
    const contactForm = document.getElementById('contact-form');
    const formStatus = document.querySelector('.form-status');
    
    if (contactForm) {
        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Basic form validation
            const name = contactForm.querySelector('#name').value.trim();
            const email = contactForm.querySelector('#email').value.trim();
            const subject = contactForm.querySelector('#subject').value.trim();
            const message = contactForm.querySelector('#message').value.trim();
            
            if (!name || !email || !subject || !message) {
                showFormStatus('error', 'Please fill out all fields.');
                return;
            }
            
            // Validate email format
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showFormStatus('error', 'Please enter a valid email address.');
                return;
            }
            
            // Show loading state
            const submitButton = contactForm.querySelector('button[type="submit"]');
            const originalText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            
            // Simulate form submission (replace with actual API call in production)
            try {
                // Simulate network delay
                await new Promise(resolve => setTimeout(resolve, 1500));
                
                // In a real application, you would send data to your server here
                // const response = await fetch('/api/contact', {
                //     method: 'POST',
                //     headers: {
                //         'Content-Type': 'application/json'
                //     },
                //     body: JSON.stringify({ name, email, subject, message })
                // });
                
                // if (!response.ok) throw new Error('Failed to send message');
                
                // Simulate successful submission
                showFormStatus('success', 'Thank you! Your message has been sent successfully.');
                contactForm.reset();
                
            } catch (error) {
                console.error('Contact form error:', error);
                showFormStatus('error', 'Failed to send message. Please try again later.');
            } finally {
                // Reset button state
                submitButton.disabled = false;
                submitButton.textContent = originalText;
            }
        });
    }
    
    /**
     * Display status message for the form
     */
    function showFormStatus(type, message) {
        if (formStatus) {
            formStatus.textContent = message;
            formStatus.className = `form-status ${type}`;
            formStatus.style.display = 'block';
            
            // Hide status message after 5 seconds
            setTimeout(() => {
                formStatus.style.display = 'none';
            }, 5000);
        }
    }
}

/**
 * Check authentication status and update header buttons
 */
async function checkAuthStatus() {
    try {
        // In a real app, you would check auth status with Supabase or your auth provider
        // Here we're checking if the auth module is available
        if (typeof supabase !== 'undefined') {
            const { data: { user }, error } = await supabase.auth.getUser();
            
            if (user) {
                // User is logged in, update header buttons
                const authButtons = document.querySelector('.auth-buttons');
                if (authButtons) {
                    authButtons.innerHTML = `
                        <a href="dashboard.html" class="btn btn-primary">Dashboard</a>
                        <button id="header-logout-btn" class="btn btn-outline">Logout</button>
                    `;
                    
                    // Add logout functionality
                    const logoutBtn = document.getElementById('header-logout-btn');
                    if (logoutBtn) {
                        logoutBtn.addEventListener('click', async () => {
                            try {
                                await supabase.auth.signOut();
                                window.location.reload();
                            } catch (error) {
                                console.error('Logout error:', error);
                            }
                        });
                    }
                }
            }
        }
    } catch (error) {
        console.error('Auth check error:', error);
    }
} 