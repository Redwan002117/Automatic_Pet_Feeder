/**
 * Profile management script for Automatic Pet Feeder
 */

document.addEventListener('DOMContentLoaded', () => {
    initSupabase();
    checkAuth();
    
    // Set up event listeners
    document.querySelectorAll('.profile-form').forEach(form => {
        form.addEventListener('submit', handleProfileUpdate);
    });
    
    document.querySelectorAll('.password-form').forEach(form => {
        form.addEventListener('submit', handlePasswordUpdate);
    });
    
    document.querySelectorAll('.notification-form').forEach(form => {
        form.addEventListener('submit', handleNotificationUpdate);
    });
    
    // Preview profile image
    const profileImageInput = document.getElementById('profile-image');
    if (profileImageInput) {
        profileImageInput.addEventListener('change', previewProfileImage);
    }
    
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', togglePasswordVisibility);
    });
    
    // Delete account button
    const deleteAccountBtn = document.getElementById('delete-account-btn');
    if (deleteAccountBtn) {
        deleteAccountBtn.addEventListener('click', confirmDeleteAccount);
    }
    
    // Export data button
    const exportDataBtn = document.getElementById('export-data-btn');
    if (exportDataBtn) {
        exportDataBtn.addEventListener('click', exportUserData);
    }
});

// Initialize Supabase client
function initSupabase() {
    const SUPABASE_URL = window.SUPABASE_URL;
    const SUPABASE_KEY = window.SUPABASE_KEY;
    window.supabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
}

// Check authentication status
async function checkAuth() {
    const { data: { user } } = await window.supabase.auth.getUser();
    if (!user) {
        window.location.href = '/login.html';
        return;
    }
    
    loadUserProfile();
}

// Load user profile data
async function loadUserProfile() {
    showLoading('.profile-container');
    
    const { data: { user } } = await window.supabase.auth.getUser();
    
    // Get profile data
    const { data: profile, error } = await window.supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
    
    hideLoading('.profile-container');
    
    if (error) {
        console.error('Error loading profile:', error);
        showError('.profile-container', 'Failed to load profile data');
        return;
    }
    
    // Fill profile form
    fillProfileForm(user, profile);
    
    // Get notification settings
    loadNotificationSettings();
}

// Fill profile form with user data
function fillProfileForm(user, profile) {
    // Basic user info
    document.getElementById('user-email').value = user.email;
    document.getElementById('user-email').disabled = true;
    
    document.getElementById('full-name').value = profile?.full_name || '';
    document.getElementById('phone').value = profile?.phone || '';
    
    // Profile image
    const profileImagePreview = document.getElementById('profile-image-preview');
    if (profileImagePreview && profile?.avatar_url) {
        profileImagePreview.src = profile.avatar_url;
        profileImagePreview.style.display = 'block';
    }
    
    // Account info display
    const createdAt = new Date(user.created_at);
    document.getElementById('account-created').textContent = createdAt.toLocaleDateString();
    
    // Last login time
    const lastSignIn = new Date(user.last_sign_in_at);
    document.getElementById('last-login').textContent = lastSignIn.toLocaleDateString() + ' at ' + lastSignIn.toLocaleTimeString();
}

// Load notification settings
async function loadNotificationSettings() {
    const { data: { user } } = await window.supabase.auth.getUser();
    
    // Get notification settings
    const { data: settings, error } = await window.supabase
        .from('notification_settings')
        .select('*')
        .eq('user_id', user.id)
        .single();
    
    if (error && error.code !== 'PGRST116') { // PGRST116 is "row not found" error
        console.error('Error loading notification settings:', error);
        return;
    }
    
    // Fill notification form
    if (settings) {
        document.getElementById('email-notifications').checked = settings.email_enabled;
        document.getElementById('browser-notifications').checked = settings.browser_enabled;
        document.getElementById('feeding-notifications').checked = settings.feeding_alerts;
        document.getElementById('food-level-notifications').checked = settings.food_level_alerts;
        document.getElementById('device-offline-notifications').checked = settings.device_offline_alerts;
        document.getElementById('weekly-summary').checked = settings.weekly_summary;
    } else {
        // Default settings (all enabled)
        document.querySelectorAll('.notification-form input[type="checkbox"]').forEach(checkbox => {
            checkbox.checked = true;
        });
    }
}

// Preview profile image before upload
function previewProfileImage(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(event) {
        const imgPreview = document.getElementById('profile-image-preview');
        imgPreview.src = event.target.result;
        imgPreview.style.display = 'block';
    };
    reader.readAsDataURL(file);
}

// Toggle password visibility
function togglePasswordVisibility(e) {
    const button = e.currentTarget;
    const passwordInput = button.previousElementSibling;
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        button.innerHTML = '<i class="fas fa-eye-slash"></i>';
    } else {
        passwordInput.type = 'password';
        button.innerHTML = '<i class="fas fa-eye"></i>';
    }
}

// Handle profile update form submission
async function handleProfileUpdate(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    
    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
    submitBtn.disabled = true;
    
    const { data: { user } } = await window.supabase.auth.getUser();
    
    const fullName = form.querySelector('#full-name').value;
    const phone = form.querySelector('#phone').value;
    
    // Prepare profile data
    const profileData = {
        id: user.id,
        full_name: fullName,
        phone: phone,
        updated_at: new Date().toISOString()
    };
    
    // Handle profile image upload if provided
    const profileImageInput = form.querySelector('#profile-image');
    if (profileImageInput && profileImageInput.files.length > 0) {
        const file = profileImageInput.files[0];
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}_${Date.now()}.${fileExt}`;
        
        const { data: uploadData, error: uploadError } = await window.supabase.storage
            .from('avatars')
            .upload(fileName, file, { upsert: true });
        
        if (uploadError) {
            submitBtn.innerHTML = 'Save Changes';
            submitBtn.disabled = false;
            showToast('Error uploading profile image: ' + uploadError.message, 'error');
            return;
        }
        
        // Get the public URL for the uploaded image
        const { data: { publicUrl } } = window.supabase.storage
            .from('avatars')
            .getPublicUrl(fileName);
        
        profileData.avatar_url = publicUrl;
    }
    
    // Update profile
    const { error } = await window.supabase
        .from('profiles')
        .upsert(profileData);
    
    // Reset form state
    submitBtn.innerHTML = 'Save Changes';
    submitBtn.disabled = false;
    
    if (error) {
        showToast('Error updating profile: ' + error.message, 'error');
        return;
    }
    
    showToast('Profile updated successfully!', 'success');
}

// Handle password update form submission
async function handlePasswordUpdate(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    
    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Changing...';
    submitBtn.disabled = true;
    
    const currentPassword = form.querySelector('#current-password').value;
    const newPassword = form.querySelector('#new-password').value;
    const confirmPassword = form.querySelector('#confirm-password').value;
    
    // Check if passwords match
    if (newPassword !== confirmPassword) {
        submitBtn.innerHTML = 'Change Password';
        submitBtn.disabled = false;
        showToast('New passwords do not match', 'error');
        return;
    }
    
    // Validate password strength
    if (!isPasswordStrong(newPassword)) {
        submitBtn.innerHTML = 'Change Password';
        submitBtn.disabled = false;
        showToast('Password must be at least 8 characters with at least one uppercase letter, one lowercase letter, one number, and one special character', 'error');
        return;
    }
    
    // Get current user session
    const { data: { session } } = await window.supabase.auth.getSession();
    
    // You cannot directly verify the current password with Supabase Auth
    // This is a limitation of the Auth API. In a real app, you would need a backend endpoint to verify the current password.
    // For this demo, we'll skip current password verification.
    
    // Update password
    const { error } = await window.supabase.auth.updateUser({
        password: newPassword
    });
    
    // Reset form state
    submitBtn.innerHTML = 'Change Password';
    submitBtn.disabled = false;
    
    if (error) {
        showToast('Error changing password: ' + error.message, 'error');
        return;
    }
    
    // Clear form
    form.reset();
    
    showToast('Password changed successfully!', 'success');
}

// Handle notification settings update
async function handleNotificationUpdate(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    
    // Show loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
    submitBtn.disabled = true;
    
    const { data: { user } } = await window.supabase.auth.getUser();
    
    // Get form values
    const emailEnabled = form.querySelector('#email-notifications').checked;
    const browserEnabled = form.querySelector('#browser-notifications').checked;
    const feedingAlerts = form.querySelector('#feeding-notifications').checked;
    const foodLevelAlerts = form.querySelector('#food-level-notifications').checked;
    const deviceOfflineAlerts = form.querySelector('#device-offline-notifications').checked;
    const weeklySummary = form.querySelector('#weekly-summary').checked;
    
    // Prepare settings data
    const settingsData = {
        user_id: user.id,
        email_enabled: emailEnabled,
        browser_enabled: browserEnabled,
        feeding_alerts: feedingAlerts,
        food_level_alerts: foodLevelAlerts,
        device_offline_alerts: deviceOfflineAlerts,
        weekly_summary: weeklySummary,
        updated_at: new Date().toISOString()
    };
    
    // Upsert notification settings
    const { error } = await window.supabase
        .from('notification_settings')
        .upsert(settingsData);
    
    // Reset form state
    submitBtn.innerHTML = 'Save Settings';
    submitBtn.disabled = false;
    
    if (error) {
        showToast('Error updating notification settings: ' + error.message, 'error');
        return;
    }
    
    showToast('Notification settings updated successfully!', 'success');
    
    // Request browser notification permission if enabled
    if (browserEnabled) {
        requestNotificationPermission();
    }
}

// Request browser notification permission
function requestNotificationPermission() {
    if (!('Notification' in window)) {
        showToast('This browser does not support desktop notifications', 'info');
        return;
    }
    
    if (Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                showToast('Notification permission granted!', 'success');
            } else if (permission === 'denied') {
                showToast('Notification permission denied', 'error');
                // Update checkbox to reflect actual state
                document.getElementById('browser-notifications').checked = false;
            }
        });
    }
}

// Confirm before deleting account
function confirmDeleteAccount() {
    const modal = document.getElementById('delete-account-modal');
    modal.classList.add('active');
    
    // Add event listener for confirmation
    const confirmBtn = modal.querySelector('.confirm-delete');
    const cancelBtn = modal.querySelector('.cancel-delete');
    
    confirmBtn.addEventListener('click', deleteAccount);
    
    cancelBtn.addEventListener('click', () => {
        modal.classList.remove('active');
    });
}

// Delete user account
async function deleteAccount() {
    const modal = document.getElementById('delete-account-modal');
    const confirmBtn = modal.querySelector('.confirm-delete');
    
    // Show loading state
    confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Deleting...';
    confirmBtn.disabled = true;
    
    const { data: { user } } = await window.supabase.auth.getUser();
    
    // First delete all user data from related tables
    try {
        // Delete user's pets
        await window.supabase.from('pets').delete().eq('user_id', user.id);
        
        // Delete user's devices
        await window.supabase.from('devices').delete().eq('user_id', user.id);
        
        // Delete user's feeding schedules
        await window.supabase.from('feeding_schedules').delete().eq('user_id', user.id);
        
        // Delete user's feeding history
        await window.supabase.from('feeding_history').delete().eq('user_id', user.id);
        
        // Delete user's notification settings
        await window.supabase.from('notification_settings').delete().eq('user_id', user.id);
        
        // Delete user's profile
        await window.supabase.from('profiles').delete().eq('id', user.id);
        
        // Finally, delete the user from auth
        const { error } = await window.supabase.auth.admin.deleteUser(user.id);
        
        if (error) {
            throw error;
        }
        
        // Sign out the user
        await window.supabase.auth.signOut();
        
        // Redirect to homepage
        window.location.href = '/index.html';
        
    } catch (error) {
        console.error('Error deleting account:', error);
        confirmBtn.innerHTML = 'Delete Account';
        confirmBtn.disabled = false;
        modal.classList.remove('active');
        showToast('Error deleting account: ' + error.message, 'error');
    }
}

// Export user data
async function exportUserData() {
    showToast('Preparing your data export...', 'info');
    
    const { data: { user } } = await window.supabase.auth.getUser();
    
    try {
        // Get user profile
        const { data: profile } = await window.supabase
            .from('profiles')
            .select('*')
            .eq('id', user.id)
            .single();
        
        // Get user's pets
        const { data: pets } = await window.supabase
            .from('pets')
            .select('*')
            .eq('user_id', user.id);
        
        // Get user's devices
        const { data: devices } = await window.supabase
            .from('devices')
            .select('*')
            .eq('user_id', user.id);
        
        // Get user's feeding schedules
        const { data: feedingSchedules } = await window.supabase
            .from('feeding_schedules')
            .select('*')
            .eq('user_id', user.id);
        
        // Get user's feeding history
        const { data: feedingHistory } = await window.supabase
            .from('feeding_history')
            .select('*')
            .eq('user_id', user.id);
        
        // Get user's notification settings
        const { data: notificationSettings } = await window.supabase
            .from('notification_settings')
            .select('*')
            .eq('user_id', user.id);
        
        // Combine all data
        const userData = {
            user: {
                id: user.id,
                email: user.email,
                created_at: user.created_at,
                last_sign_in_at: user.last_sign_in_at
            },
            profile: profile || {},
            pets: pets || [],
            devices: devices || [],
            feeding_schedules: feedingSchedules || [],
            feeding_history: feedingHistory || [],
            notification_settings: notificationSettings || {}
        };
        
        // Create and download JSON file
        const dataStr = JSON.stringify(userData, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        
        // Set file name with current date
        const today = new Date().toISOString().split('T')[0];
        link.setAttribute('href', url);
        link.setAttribute('download', `pet-feeder-data-${today}.json`);
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showToast('Your data has been exported successfully!', 'success');
        
    } catch (error) {
        console.error('Error exporting data:', error);
        showToast('Error exporting data: ' + error.message, 'error');
    }
}

// Check if password is strong
function isPasswordStrong(password) {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChars = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return (
        password.length >= minLength &&
        hasUpperCase &&
        hasLowerCase &&
        hasNumbers &&
        hasSpecialChars
    );
}

// Helper functions
function showLoading(selector) {
    const container = document.querySelector(selector);
    container.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
}

function hideLoading(selector) {
    const container = document.querySelector(selector);
    const spinner = container.querySelector('.loading-spinner');
    if (spinner) {
        spinner.remove();
    }
}

function showError(selector, message) {
    const container = document.querySelector(selector);
    container.innerHTML = `<div class="error-message"><i class="fas fa-exclamation-circle"></i> ${message}</div>`;
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close"><i class="fas fa-times"></i></button>
    `;
    
    document.body.appendChild(toast);
    
    // Show toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Auto hide after 5 seconds
    setTimeout(() => {
        hideToast(toast);
    }, 5000);
    
    // Add event listener for close button
    toast.querySelector('.toast-close').addEventListener('click', () => {
        hideToast(toast);
    });
}

function hideToast(toast) {
    toast.classList.remove('show');
    setTimeout(() => {
        toast.remove();
    }, 300);
} 